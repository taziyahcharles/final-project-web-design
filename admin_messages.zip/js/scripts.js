// small interactions
console.log('Pet Haven ready');